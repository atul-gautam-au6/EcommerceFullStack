export default {
    JWT_SECRET_KEY:'@#$thisisaSecratekey'
}
